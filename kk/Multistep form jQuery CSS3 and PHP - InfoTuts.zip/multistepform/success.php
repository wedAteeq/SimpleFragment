<!doctype HTML>
<html>
<head>
<title>success form</title>
<link rel="stylesheet" type="text/css" href="style.css">

</head>
<body>
<div id="mhead"><h2>Multi Step Form with Progress Bar using jQuery, CSS3 and PHP - <span class="red">Info</span>Tuts</h2></div>
<div id="message">
<span class="success">
<h3>Data Successfully submitted in database.</h3>
</span>
<a href="http://localhost/multistepform">Back to Form</a> 
</div>
</body>
</html>